<section class="footer">
				<footer id="one">
					<a name="social"></a>
					<p>Các bạn có thể liên hệ với chúng mình qua:</p>
					<a href=""><img
							src="https://cdn3.iconfinder.com/data/icons/free-social-icons/67/facebook_circle_color-256.png"
							height="15%" width="15%"></a>
					<a href=""><img
							src="https://cdn1.iconfinder.com/data/icons/iconza-circle-social/64/697029-twitter-256.png"
							height="15%" width="15%"></a>
					<a href=""><img
							src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Instagram_icon.png/599px-Instagram_icon.png"
							height="15%" width="15%"></a>
				</footer>
				<footer id="two"><b>&copy;2019 page created by </br><a href="#" id="link">K62J</a></b></footer>
			</section>