@extends('news.layout.single')

@section('content')
<!-- Content -->
<section id="content" class="ten column row pull-left">
	<div class="page-container error-404">
		<p>error <b>404</b><span>Xin lỗi, Trang này có thể bị xóa hoặc không tồn tại.</span></p>
	</div>
</section>
<!-- Content -->
@endsection