<div id nav-bar>
			<a href="" id="logo"></a>
			<nav>
				<a href="#" id="menu-icon"></a>
				<ul>
					<li><a href="#About">Về chúng tôi</a></li>
					<li><a href="#Contact">Liên hệ</a></li>
					<li><a href="#Product">Thư viện sách</a></li>
					<li><a href="userform.html">Thông tin cá nhân</a></li>
					<?php 
						
					?>
				</ul>
			</nav>
		</div>