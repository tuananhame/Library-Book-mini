<section class="info">
				<div class="sliding" style="max-width:45%">
					<img class="mySlides" src="http://www.bleedingcool.com/wp-content/uploads/2010/06/h4.jpg"
						height="30%" style="width:100%">
					<img class="mySlides"
						src="http://explorebkv2.wpengine.com/wp-content/uploads/2015/02/galaxy-comics-park-slope-brooklyn-comic-book-store.jpg"
						height="30%" style="width:100%">
					<img class="mySlides" src="http://www.808talk.com/wp-content/uploads/2008/10/jellys.jpg"
						height="30%" style="width:100%">
				</div>



				<h1 align="center">Về chúng tôi</h1>
				<p>“Sách hay, cũng như bạn tốt, ít và được chọn lựa; chọn lựa càng nhiều, thưởng thức càng nhiều." Ở đây
					chúng mình không bán sách mà chỉ trao đổi sách với nhau. Hãy cùng nhau xây dựng 1 thư viện cho riêng
					mình tại đây nhé ^^
				</p>
				<img src="http://thcsdaoduytuhn.vn/wp-content/uploads/2018/09/0.jpeg" height="30%" width="50%" id="loc">
			</section>